import { handleSubmitForMeaningCloud } from '../client/js/formHandler';

test('submit test', () => {
    expect(handleSubmitForMeaningCloud).toBeDefined();
});