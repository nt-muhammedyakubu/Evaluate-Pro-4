const dotenv = require('dotenv');
dotenv.config();
console.log(`"https://api.meaningcloud.com/sentiment-2.1?key=<9eea55e36716c9c438c6c0094693c168>&lang=<lang>&txt=<text>&model=<model>" ${process.env.API_Key}`);

var path = require('path')
var express = require('express');
const mockAPIResponse = require('./mockAPI.js');
var app = express();
var bodyParser = require('body-parser')
var requestPost = require('./handleRequest');
var cors = require('cors');
var meaningcloud = require('meaningcloud_textapi')

app.use(cors())
app.use(bodyParser.json())

app.use(bodyParser.urlencoded({
    extended: true
}))
app.use(express.static('dist'));


app.get('/', function(req, res) {
    // res.sendFile('dist/index.html')
    res.sendFile('dist/index.html');
});

// designates what port the app will listen to for incoming requests
const port = 3000;
app.listen(port, function() {
    console.log(`Evaluate NLP app's server listening on port ${port}!`);
});

app.get('/test', function(req, res) {
    res.send(mockAPIResponse)
});
// Post
app.post('/api', requestPost.validateInputRequest, requestPost.PostHandler);

module.exports = app;