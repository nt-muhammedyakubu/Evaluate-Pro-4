const app = require('./app');

app.listen(3000, function() {
    console.log("Server starts on port 3000");
});